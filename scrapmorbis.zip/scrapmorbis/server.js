const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const path = require('path');

const app = express();
const port = 3000;

// Directory for static files
app.use(express.static(path.join(__dirname, 'public')));

// URL dari website pertama yang ingin di-scrape
const sourceUrl = 'http://36.64.121.125/mitramedikabatanghari/public/ketersediaan-bed'; // Ganti dengan URL yang sesuai

// Endpoint untuk scraping data ketersediaan kamar
app.get('/scrape-room-availability', async (req, res) => {
  try {
    const response = await axios.get(sourceUrl);
    const html = response.data;
    const $ = cheerio.load(html);

    let rooms = [];
    $('.well').each((i, elem) => {
      const name = $(elem).find('p').first().text().trim().replace(/\s+/g, ' ');
      const availability = $(elem).find('span[id^="sisa"]').text().trim();
      const capacity = $(elem).find('span[id^="tampung"]').text().trim();

      rooms.push({ name, availability, capacity });
    });

    // console.log('Scraped data:', rooms); // Debugging: log data yang di-scrape
    res.json({ rooms });
  } catch (error) {
    // console.error('Error scraping room availability:', error); // Debugging: log kesalahan
    res.status(500).send('Error scraping room availability');
  }
});

// Jalankan server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});
