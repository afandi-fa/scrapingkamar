const scrapeUrl = '/scrape-room-availability';

async function fetchRoomAvailability() {
    try {
        const response = await fetch(scrapeUrl);
        const data = await response.json();
        console.log('Fetched data:', data); // Debugging: log data yang di-fetch
        updateRoomAvailability(data);
    } catch (error) {
        console.error('Error fetching room availability:', error); // Debugging: log kesalahan
    }
}

function updateRoomAvailability(data) {
    const availabilityDiv = document.getElementById('room-availability');
    availabilityDiv.innerHTML = ''; // Kosongkan konten sebelumnya

    data.rooms.forEach(room => {
        const roomElement = document.createElement('div');
        roomElement.className = 'room';

        const roomName = document.createElement('h3');
        roomName.textContent = room.name;
        roomElement.appendChild(roomName);

        const roomAvailability = document.createElement('p');
        roomAvailability.innerHTML = `<strong>${room.availability}</strong> tersedia dari <strong>${room.capacity}</strong>`;
        roomElement.appendChild(roomAvailability);

        availabilityDiv.appendChild(roomElement);
    });
}

setInterval(fetchRoomAvailability, 5000); // Ambil data setiap 5 detik
fetchRoomAvailability(); // Ambil data saat halaman dimuat pertama kali
